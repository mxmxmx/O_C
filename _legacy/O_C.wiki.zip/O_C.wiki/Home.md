#o_c

start [here](https://github.com/mxmxmx/O_C/wiki/hardware-basics) and make sure to take a look [here](https://github.com/mxmxmx/O_C/wiki/decisions)

![](https://farm4.staticflickr.com/3948/15552392087_8fb300d861_c.jpg)

