# building the thing

### populate the board: 

- before doing anything, read [this](https://github.com/mxmxmx/O_C/wiki/decisions) first. other than that, you can follow the values printed on the boards. it's a easy + quick build, generally speaking. this is how it should look, with all the trimpots installed: (note here i put an additional trimpot where the jumper or switch is supposed to go, you don't want to do that.)




![](https://farm9.staticflickr.com/8586/15840079610_294e38c2e7_b.jpg)

- no particular precautions required, **except: the unlabelled parts near the bottom should be 33k resistors** (not diodes, as the silkscreen has it) -- see picture below. (ignore the mounting holes/pin headers next to the jacks / underneath the button -- unless you wanted to build a (display-less) 4HP version (say), with the board mounted vertically).

![](https://farm8.staticflickr.com/7560/15852596529_15083f33bf_b.jpg)

- jacks: the jacks share the ground pad, facing each other:

![](https://farm8.staticflickr.com/7523/15841583607_9831411ac0_b.jpg)

- encoders: if using the bourns ones, they're not tall enough. you have to solder them onto the top side of the board, so that they line up with the jacks:

![](https://farm8.staticflickr.com/7481/15840079890_d7bf79a39f_b.jpg)

- oled: use a low profile socket; you'll have to trim the pins somewhat so as to make things fit / line up with the other components (ie jacks, encoders):

![](https://farm8.staticflickr.com/7508/16027321145_e3c8ff81c2_b.jpg)

- finally. prepare the teensy: **you have to cut one trace**:

![](http://www.teensypi.com/wp-content/gallery/teensy3-0/teensy3_0cut.png)

