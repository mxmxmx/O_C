# firmware

- first, if you don’t have it already, you need to install arduino/teensyduino (https://www.pjrc.com/teensy/teensyduino.html). Make sure you install the latest version.
- you then need to install three [libraries](https://github.com/mxmxmx/O_C/tree/master/software/libraries): one for the encoders (**rotaryplus**); **spi4teensy** (needed for the DAC) and **u8glib** to drive the display. put them in your libraries folder and restart the arduino IDE.
- once the libraries are there, you should be able to compile the o_c firmware; upload it to your board. the display should come to life now:


![](https://farm8.staticflickr.com/7520/15839908268_0a8cf8c521_b.jpg)