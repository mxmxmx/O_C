#calibration:


- there's a little calibration menu, which is entered by keeping the left encoder pushed down during start up. on the display, something like this should appear: 

`--> calibrate:`

`use encoder (R)`

`switch left pos.`

- you'll also need: a good multimeter (ideally, 40000 counts +).

- if installed, the panel switch should be in the left position (unipolar). it'll work much the same if you opted for bipolar, just subtract 5.000v (in each step (1V-10V)); the four 2k trimpots map to the panel jacks as follows: #1: top left; #2: top right; #3 bottom left; #4 bottom right (ignore the 'offset' trimpot show in the picture):

![](https://farm8.staticflickr.com/7504/16025475221_d2666fe03c_b.jpg)


- 1/ now push the right encoder to continue. you'll see something like:

`trim center value:`

`- > 5.000V`

`use trimpots!`

- 2/ in this first step, we use the four **trimpots** to adjust the four outputs (each), to get the gain approx. right. (the fifth is for the ADC, we'll do that later; (the DAC code may also be adjusted in this step, but normally this should not be necessary). adjust until your (hopefully good) multimeter sees ~ 5.000V at each output. push the encoder when done.

- 3/ the next few steps are all identical (use any jack): e.g.

`trim to 1 volts`

`--> 1.000V / 6553`

`use encoder!`

- use your multimeter to adjust output A to read 1.000V (you might also use your ear or a tuner, of course) -- **this time, we adjust the DAC code** (if necessary - typically, not a whole lot of adjustment should be necessary; it'll depend somewhat on the components used): turn the right encoder to change the output value to the desired value; push it, when done. tune the next octave. for instance:

![](https://farm8.staticflickr.com/7551/15841280319_d41dd15e3e_b.jpg)

- 4/ the final step (tune "0.08333v" / board rev 0 only) takes care of the offset, which likely is to be present. it works just as before: turn the encoder until the output is 0.08333v 

- when done, push the encoder again to save the DAC code, and you're back in the main programme. if not happy with the results (the extreme ends might need a little extra care / trim-pot adjustment), you can clear the results by pressing the top button and start over.


 

