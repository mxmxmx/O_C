#decisions, decisions

###outputs/DAC

before building up things + sourcing parts + making panels, here's a basic decision you need to make; namely, how should the output stage behave?

there's two options:  output range is

- selectable by jumper: 0/+10v **or** -5v/+5v
- selectable by pcb mount switch: 0/+10v << >> -5v/+5v

the first option has the advantage that it's flexible and straightforward; the second offers much the same, but you have the switch accessible on the panel. **note that obviously that'll have implications re: panel design**. as noted in the BOM, using better-than-the-usual op amps (ie the DC 'precision' kind: very low offset/noise etc) has advantages, too.

this is the circuit we're looking at (not all caps are shown):

![](https://farm8.staticflickr.com/7518/15346231313_ce69089ac7_b.jpg)


the first op amp provides the (negative) offset (and 2x gain), the second one is 2x gain again, with some fine tuning (all this could be had simpler, with just one op amp, but this is how i did it here).  there's a few things to note. first, note the resistors are all 10k (except the one 9k1+trimpot), so you could use pretty much any resistor value, what counts isn't the absolute value but how precise those values are (not too large/small of course; also the cap may need adjustment). you often can get weird values of 0.1% resistors on ebay for cheap, so that'll be an alternative to matching 0805 parts. second, the part on the lower left: **that's where you can put either the jumper or subminiature switch** (*): the footprint is 3 pin / 2.54mm, so either of those can be fitted. in my experience, it's difficult to make the four channels behave exactly (absolutely) the same; that would really need four look up tables in the code (and which i'll probably add). but each channel individually behaves linear enough so that the outcome is still very good.


( * ) it needs to be really miniature, like this one: 

![](https://farm8.staticflickr.com/7516/15780258497_9d941f9715_t.jpg)


###inputs/ADC

on the input side, the choices are less significant, but here are two:

- as per BOM/values printed on the pcb, all the inputs are bipolar. if you prefer unipolar (or V/oct), you could either: trim the inputs to unipolar (there's a trimpot providing the offset) -- that'll affect **all** inputs; or, alternatively, half some of the resistor values; the circuit is a simple inverting op amp. (schematic + details follow)


- using precision references? for the purposes of this ASR, this isn't really needed. we don't need that much resolution, so even with the vanilla regulators, that'll do. if you have other plans though, the board offers the option to install a lm4040 (sot-23) to be used as the AREF for the teensy (both the 2.5v and 3.0v version are suitable choices; in theory, 3.0v is the better one, SNR wise. to use it, you'll have to run a jumper wire to from the SMD pad to the AREF pin). note that'll affect your CV input range, so the input stage might need some adjustment, too. (ie, more attenuation). the 79L05 regulator too can be replaced with a LM4040 (TO-92) very easily. 
