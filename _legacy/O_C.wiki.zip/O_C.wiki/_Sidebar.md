[hardware - basics](https://github.com/mxmxmx/O_C/wiki/hardware-basics)

[decisions, decisions](https://github.com/mxmxmx/O_C/wiki/decisions)

[build it](https://github.com/mxmxmx/O_C/wiki/build-it)

[firmware](https://github.com/mxmxmx/O_C/wiki/firmware)

[calibration](https://github.com/mxmxmx/O_C/wiki/calibration)