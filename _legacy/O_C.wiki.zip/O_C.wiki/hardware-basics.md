#hardware basics

o_C is a fairly straight-forward breakout board for teensy 3.x; somewhat like a pimped-up ardcore, though its focus is on generating pitch CV rather than being general purpose (see the circuit below). **the board features four 16 bit CV outputs (10V range), courtesy of DAC8565/8564 (either could be used). in addition, there's four CV inputs (12 bit, 10V range) as well as four digital inputs.** 

the example firmware is a quantizing ASR; other possible uses would include: dual sequencer; quad quantizer; pitch CV generators; usb-midi to CV stuff. as the DAC shares the SPI port with the OLED display, it's less suitable for devices that need to write to the DAC at high(er) sample rates (LFOs etc). that said, using the OLED (and/or encoders) isn't a must. other SPI devices might be attached; or pots be used instead of the encoders (more details below). the board could also be mounted vertically, as a 4-6HP module: there's two mounting holes.
 

i drew the schematic by hand (which is to say, in pcb-view), so i don't have a proper one. sorry. but it's all generic digital module stuff; here's the basics, anyway.

- output: rev 0: two non-inverting op amps in series, providing offset and amplification; output resistor inside the feedback loop to minimize the error. (more details [here](https://github.com/mxmxmx/O_C/wiki/decisions)). rev 1 has only one inverting op amp, and an additional trimpot for adjusting the offset. pictured below is rev 0 (evidently):

![](https://camo.githubusercontent.com/4dfd88ba21457caf917958711de48aeb04efaef6/68747470733a2f2f6661726d382e737461746963666c69636b722e636f6d2f373531382f31353334363233313331335f636536393038396163375f622e6a7067)

- CV inputs: inverting op amp with negative offset (via trimpot). typically, the offset will be set to half the ADC range, so the inputs will be 'bipolar' (+/- 5V). (note the inputs have to be inverted in the software):

![](https://farm8.staticflickr.com/7564/15926519627_4b49ebe6d0_c.jpg)

- digital inputs: wired as transistor switches, directly to the respective GPIO pins: collector tied to 3V3 via a series resistor; emitter to ground; the trigger signals go into the base via a 100k series resistor and 33k to ground. (pcb rev 0 says diode to ground (unlabelled) – ignore this.

- encoders: the encoders use pins 14, 15, 16 resp. 21, 22, 23 (any or all of these pins could be wired as/to potentiometers); the two tact switches use pins 4 and 5.